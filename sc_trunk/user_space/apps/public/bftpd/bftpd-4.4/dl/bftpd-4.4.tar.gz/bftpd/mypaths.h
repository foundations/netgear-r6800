#define PATH_BFTPD_CONF "/etc/bftpd.conf"
#ifdef PREFIX
#define PATH_BFTPD_CONF_WITH_PREFIX PREFIX"/etc/bftpd.conf"
#endif
#define PATH_STATUSLOG "/dev/null"
